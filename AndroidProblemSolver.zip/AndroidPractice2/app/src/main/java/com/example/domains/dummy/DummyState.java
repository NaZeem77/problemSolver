package com.example.domains.dummy;

import com.example.framework.problem.State;
import java.util.Objects;
import java.util.stream.Stream;

public class DummyState extends State {
    
        public DummyState(String contents) {
            this.contents = contents;
        }

        @Override
        public boolean equals(Object other) {
            DummyState otherDummy = (DummyState) other;
            return this.contents.equals(otherDummy.contents);
        }

        @Override
        public String toString() {
            String[] lines = contents.split("/");
            Stream<Integer> lengths = Stream.of(lines).map(String::length);
            int maxLength = lengths.max(Integer::compare).get();

            StringBuilder sb = new StringBuilder();
            addDashes(sb, maxLength + 2);
            sb.append(NEW_LINE);
            for (String line : lines) {
                sb.append("| ");
                sb.append(String.format("%1$-" + maxLength + "s", line));
                sb.append(" |");
                sb.append(NEW_LINE);
            }
            addDashes(sb, maxLength + 2);
            return sb.toString();
        }

        @Override
	public int hashCode() {
	    int hash = 7;
	    hash = 37 * hash + Objects.hashCode(this.contents);
	    return hash;
	}

        private void addDashes(StringBuilder sb, int n) {
            sb.append("+");
            for (int i = 0; i < n; i++) {
                sb.append("-");
            }
            sb.append("+");
        }

        private final String contents;

        private static final String NEW_LINE = "\n";
    }